<?php require ('inc/header.php')?>




<section class="blog-listing-page">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 col-md-12 col-sm-12">
                <div class="listing-wrap">
                    <a class="listing-link-wrap row" href="#">
                        <div class="col-lg-4 col-md-4 col-sm-12">
                            <figure class="listing-image" style="background-image:url(images/market1.jpg)"></figure>
                        </div>
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <div class="listing-content">
                                <h2>Lorem ipsum dolor sit amet consectetur adipisicing elit. Provident dicta facere odio aspernatur laboriosam maiores quia dolore quae atque hic.</h2>
                                <span>January 5,2020</span>
                                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquam nostrum culpa quia sed quisquam! Officiis, nihil tenetur nisi quo explicabo quia et odit, amet maxime totam quod facere molestiae velit corporis. Voluptates eum repudiandae non voluptatem maxime, nemo deleniti minima nisi laboriosam alias dignissimos officiis odit illo adipisci consequatur architecto?</p>
                            </div>
                        </div>
                    </a>
                    <a class="listing-link-wrap row" href="#">
                        <div class="col-lg-4 col-md-4 col-sm-12">
                            <figure class="listing-image" style="background-image:url(images/market3.jpg)"></figure>
                        </div>
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <div class="listing-content">
                                <h2>Lorem ipsum dolor sit amet consectetur adipisicing elit. Provident dicta facere odio aspernatur laboriosam maiores quia dolore quae atque hic.</h2>
                                <span>January 5,2020</span>
                                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquam nostrum culpa quia sed quisquam! Officiis, nihil tenetur nisi quo explicabo quia et odit, amet maxime totam quod facere molestiae velit corporis. Voluptates eum repudiandae non voluptatem maxime, nemo deleniti minima nisi laboriosam alias dignissimos officiis odit illo adipisci consequatur architecto?</p>
                            </div>
                        </div>
                    </a>
                    <a class="listing-link-wrap row" href="#">
                        <div class="col-lg-4 col-md-4 col-sm-12">
                            <figure class="listing-image" style="background-image:url(images/market2.jpg)"></figure>
                        </div>
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <div class="listing-content">
                                <h2>Lorem ipsum dolor sit amet consectetur adipisicing elit. Provident dicta facere odio aspernatur laboriosam maiores quia dolore quae atque hic.</h2>
                                <span>January 5,2020</span>
                                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquam nostrum culpa quia sed quisquam! Officiis, nihil tenetur nisi quo explicabo quia et odit, amet maxime totam quod facere molestiae velit corporis. Voluptates eum repudiandae non voluptatem maxime, nemo deleniti minima nisi laboriosam alias dignissimos officiis odit illo adipisci consequatur architecto?</p>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        <div>
    </div>
</section>










<?php require ('inc/footer.php')?>