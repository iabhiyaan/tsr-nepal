 
 <!-- scroll to top arrow -->
 

 <a id="button"></a>
 
 
 <!-- footer section starts -->

        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-sm-12">
                         <div class="footer-block">
                            <h2>Analysis</h2>
                            <ul class="footer-links">
                                <li><a href="#">Technical Analysis</a></li>
                                <li><a href="#">Moving Average</a></li>
                                <li><a href="#">180 Days Avg Price</a></li>
                                <li><a href="#">Pivot Analysis</a></li>
                                <li><a href="#">Weekly Market Analysis</a></li>
                                <li><a href="#">Top Comapanies in Nepal</a></li>
                            </ul>
                         </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="footer-block">
                            <h2>News</h2>
                            <ul class="footer-links">
                                <li><a href="#">Ipo/FPO News</a></li>
                                <li><a href="#">Dividend,Right & Bonus</a></li>
                                <li><a href="#">Exclusive</a></li>
                                <li><a href="#">Company Analysis</a></li>
                                <li><a href="#">Share Listing</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="footer-block">
                            <h2>Info</h2>
                            <ul class="footer-links">
                                <li><a href="#">Share Registrar (RTS)</a></li>
                                <li><a href="#">Broker List</a></li>
                                <li><a href="#">Merchant Bankers</a></li>
                                <li><a href="#">C-ASBA BFIs</a></li>
                                <li><a href="#">DP Members</a></li>
                                <li><a href="#">IPO Results</a></li>
                                <li><a href="#">Existing Issues</a></li>
                                <li><a href="#">Upcoming Issues</a></li>
                                <li><a href="#">Ongoing Auctions </a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="footer-block">
                            <h2>Info</h2>
                            <ul class="footer-links">
                                <li><a href="#">Today's Share Price</a></li>
                                <li><a href="#">Floorsheet</a></li>
                                <li><a href="#">Indices/Sub-indices</a></li>
                                <li><a href="#">Top Transactions</a></li>
                                <li><a href="#">Top Turnovers</a></li>
                                <li><a href="#">Top Traded Shares</a></li>
                                <li><a href="#">Top Loser</a></li>
                                <li><a href="#">Top Gainers</a></li>
                                <li><a href="#">Top Brokers</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>


        <script src="js/jquery-3.4.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/lightbox.min.js"></script>
        <script src="js/custom.js"></script>
    </body>
</html>